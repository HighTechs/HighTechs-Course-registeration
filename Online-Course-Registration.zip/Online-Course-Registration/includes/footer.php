<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2023 Online Course Registration by HighTechs
                </div>

            </div>
        </div>
    </footer>

    <style> .col-md-12{text-align: center;} </style>
